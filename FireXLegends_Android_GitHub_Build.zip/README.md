# FireX Legends

Complete Android game project.

## Build from an Android phone with GitHub Actions

1. Create/sign in to a GitHub account.
2. Create a new **public or private repository**.
3. Upload **all files and folders** from this project into the repository (keep the `.github/workflows/build-apk.yml` file).
4. Open the repository → **Actions** → **Build FireX Legends APK**.
5. Tap **Run workflow**.
6. Wait for the workflow to finish.
7. Open the completed workflow run and download the **FireX-Legends-APK** artifact.
8. Extract the downloaded artifact and install `app-debug.apk` on your Android phone.

No API key, server, database, or external asset is required for this game.

## Game
- Touch/drag to aim
- Tap FIRE to shoot
- Enemies get faster as your score increases
- HP, score, game over and restart are included
