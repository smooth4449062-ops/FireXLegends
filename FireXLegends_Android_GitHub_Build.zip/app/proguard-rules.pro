# FireX Legends - no custom ProGuard rules required.
