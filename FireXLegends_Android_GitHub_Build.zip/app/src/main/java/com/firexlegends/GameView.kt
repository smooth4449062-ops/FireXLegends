package com.firexlegends

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class GameView(context: Context) : View(context) {

    private data class Bullet(var x: Float, var y: Float, var vx: Float, var vy: Float)
    private data class Enemy(var x: Float, var y: Float, var r: Float, var hp: Int, var speed: Float)

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val playerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val enemyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bulletPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val uiPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val bullets = mutableListOf<Bullet>()
    private val enemies = mutableListOf<Enemy>()

    private var px = 0f
    private var py = 0f
    private var aimX = 0f
    private var aimY = 0f
    private var score = 0
    private var hp = 100
    private var gameOver = false
    private var lastShot = 0L
    private var lastSpawn = 0L
    private var startTime = System.currentTimeMillis()
    private var dragging = false

    private val rnd = Random(System.currentTimeMillis())

    init {
        isFocusable = true
        bg.color = Color.rgb(7, 8, 15)
        text.color = Color.WHITE
        text.textSize = 48f
        uiPaint.strokeWidth = 6f
    }

    private fun resetGame() {
        bullets.clear()
        enemies.clear()
        score = 0
        hp = 100
        gameOver = false
        startTime = System.currentTimeMillis()
        lastShot = 0
        lastSpawn = 0
        px = width * 0.5f
        py = height * 0.72f
        aimX = px
        aimY = py - 200f
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        px = w * 0.5f
        py = h * 0.72f
        aimX = px
        aimY = py - 200f
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        drawBackground(c)

        if (!gameOver) {
            update()
        }

        drawArena(c)
        drawHud(c)

        if (gameOver) drawGameOver(c)

        if (!gameOver) postInvalidateDelayed(16)
    }

    private fun drawBackground(c: Canvas) {
        c.drawColor(Color.rgb(7, 8, 15))
        val horizon = height * 0.45f
        bg.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            Color.rgb(18, 10, 28),
            Color.rgb(4, 7, 12),
            Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        bg.shader = null

        // Subtle grid
        uiPaint.style = Paint.Style.STROKE
        uiPaint.color = Color.argb(35, 255, 120, 0)
        uiPaint.strokeWidth = 1f
        val step = 80f
        var x = 0f
        while (x < width) {
            c.drawLine(x, horizon, x, height.toFloat(), uiPaint)
            x += step
        }
        var y = horizon
        while (y < height) {
            c.drawLine(0f, y, width.toFloat(), y, uiPaint)
            y += step
        }
    }

    private fun drawArena(c: Canvas) {
        // FireX core glow
        val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        glow.shader = RadialGradient(
            width * .5f, height * .82f, 170f,
            Color.argb(70, 255, 80, 0),
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        c.drawCircle(width * .5f, height * .82f, 170f, glow)

        // Bullets
        bulletPaint.color = Color.rgb(255, 220, 90)
        for (b in bullets) c.drawCircle(b.x, b.y, 7f, bulletPaint)

        // Enemies
        for (e in enemies) {
            enemyPaint.color = Color.rgb(210, 35, 55)
            c.drawCircle(e.x, e.y, e.r, enemyPaint)
            enemyPaint.color = Color.rgb(255, 120, 40)
            c.drawCircle(e.x, e.y, e.r * .42f, enemyPaint)
            enemyPaint.color = Color.DKGRAY
            c.drawRect(e.x - e.r, e.y - e.r - 13, e.x + e.r, e.y - e.r - 6, enemyPaint)
            enemyPaint.color = Color.GREEN
            c.drawRect(e.x - e.r, e.y - e.r - 13,
                e.x - e.r + (2f * e.r * e.hp / 3f), e.y - e.r - 6, enemyPaint)
        }

        // Player
        playerPaint.color = Color.rgb(255, 105, 0)
        c.drawCircle(px, py, 31f, playerPaint)
        playerPaint.color = Color.WHITE
        c.drawCircle(px, py, 12f, playerPaint)

        // Aim line
        uiPaint.color = Color.argb(90, 255, 180, 80)
        uiPaint.strokeWidth = 3f
        c.drawLine(px, py, aimX, aimY, uiPaint)

        // Fire button
        uiPaint.style = Paint.Style.FILL
        uiPaint.color = Color.argb(160, 255, 75, 0)
        c.drawCircle(width - 105f, height - 115f, 70f, uiPaint)
        text.textSize = 30f
        text.color = Color.WHITE
        text.textAlign = Paint.Align.CENTER
        c.drawText("FIRE", width - 105f, height - 105f, text)
        text.textAlign = Paint.Align.LEFT
    }

    private fun drawHud(c: Canvas) {
        text.color = Color.WHITE
        text.textSize = 34f
        c.drawText("FIREX LEGENDS", 28f, 48f, text)

        text.textSize = 24f
        c.drawText("SCORE  $score", 28f, 82f, text)

        // HP bar
        val left = 28f
        val top = 105f
        val right = 290f
        uiPaint.style = Paint.Style.FILL
        uiPaint.color = Color.DKGRAY
        c.drawRoundRect(left, top, right, top + 24f, 12f, 12f, uiPaint)
        uiPaint.color = if (hp > 30) Color.rgb(60, 220, 90) else Color.RED
        c.drawRoundRect(left, top, left + (right-left) * hp / 100f, top + 24f, 12f, 12f, uiPaint)
        text.textSize = 18f
        c.drawText("HP $hp", 300f, 125f, text)

        text.textSize = 18f
        text.color = Color.LTGRAY
        c.drawText("Drag to aim • Tap FIRE to shoot", 28f, height - 25f, text)
    }

    private fun drawGameOver(c: Canvas) {
        uiPaint.color = Color.argb(210, 0, 0, 0)
        uiPaint.style = Paint.Style.FILL
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), uiPaint)

        text.textAlign = Paint.Align.CENTER
        text.color = Color.rgb(255, 90, 30)
        text.textSize = 58f
        c.drawText("GAME OVER", width/2f, height/2f - 55f, text)

        text.color = Color.WHITE
        text.textSize = 30f
        c.drawText("Score: $score", width/2f, height/2f + 5f, text)

        uiPaint.color = Color.rgb(255, 90, 30)
        c.drawRoundRect(width/2f-150f, height/2f+45f, width/2f+150f, height/2f+125f, 25f, 25f, uiPaint)
        text.color = Color.WHITE
        text.textSize = 28f
        c.drawText("PLAY AGAIN", width/2f, height/2f+97f, text)
        text.textAlign = Paint.Align.LEFT
    }

    private fun update() {
        val now = System.currentTimeMillis()

        // Spawn rate increases slowly with score.
        val spawnDelay = maxOf(280L, 900L - score.toLong() * 7L)
        if (now - lastSpawn > spawnDelay) {
            spawnEnemy()
            lastSpawn = now
        }

        // Move bullets
        val bulletIt = bullets.iterator()
        while (bulletIt.hasNext()) {
            val b = bulletIt.next()
            b.x += b.vx
            b.y += b.vy
            if (b.x < -30 || b.x > width + 30 || b.y < -30 || b.y > height + 30) {
                bulletIt.remove()
            }
        }

        // Move enemies and collisions
        val enemyIt = enemies.iterator()
        while (enemyIt.hasNext()) {
            val e = enemyIt.next()
            val dx = px - e.x
            val dy = py - e.y
            val len = maxOf(1f, kotlin.math.sqrt(dx*dx + dy*dy))
            e.x += dx / len * e.speed
            e.y += dy / len * e.speed

            if (len < e.r + 27f) {
                hp -= 12
                enemyIt.remove()
                if (hp <= 0) {
                    hp = 0
                    gameOver = true
                }
                continue
            }

            val bi = bullets.iterator()
            while (bi.hasNext()) {
                val b = bi.next()
                val bx = b.x - e.x
                val by = b.y - e.y
                if (bx*bx + by*by < (e.r + 7f)*(e.r + 7f)) {
                    bi.remove()
                    e.hp--
                    if (e.hp <= 0) {
                        enemyIt.remove()
                        score += 10
                    }
                    break
                }
            }
        }
    }

    private fun spawnEnemy() {
        val side = rnd.nextInt(4)
        val x: Float
        val y: Float
        when (side) {
            0 -> { x = rnd.nextFloat() * width; y = -50f }
            1 -> { x = width + 50f; y = rnd.nextFloat() * height }
            2 -> { x = rnd.nextFloat() * width; y = height + 50f }
            else -> { x = -50f; y = rnd.nextFloat() * height }
        }
        val speed = 1.8f + rnd.nextFloat() * 1.4f + score / 500f
        enemies.add(Enemy(x, y, 25f + rnd.nextFloat()*8f, 2, speed))
    }

    private fun shoot(x: Float, y: Float) {
        val now = System.currentTimeMillis()
        if (now - lastShot < 180L || gameOver) return
        lastShot = now

        val dx = x - px
        val dy = y - py
        val len = maxOf(1f, kotlin.math.sqrt(dx*dx + dy*dy))
        val speed = 18f
        bullets.add(Bullet(px, py, dx/len*speed, dy/len*speed))
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        if (gameOver) {
            if (event.action == MotionEvent.ACTION_UP &&
                x > width/2f - 170f && x < width/2f + 170f &&
                y > height/2f + 30f && y < height/2f + 145f) {
                resetGame()
            }
            return true
        }

        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                if (x < width - 200f || y < height - 230f) {
                    aimX = x
                    aimY = y
                    dragging = true
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (x > width - 205f && y > height - 215f) {
                    shoot(aimX, aimY)
                } else {
                    aimX = x
                    aimY = y
                    shoot(x, y)
                }
                dragging = false
                return true
            }
        }
        return true
    }
}
